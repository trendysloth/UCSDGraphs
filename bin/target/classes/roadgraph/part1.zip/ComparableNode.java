package roadgraph;

import geography.GeographicPoint;

public class ComparableNode implements Comparable<ComparableNode>{
	GeographicPoint location;
	Double dist;
	Double dist2;
	
	public ComparableNode() {
		super();
	}
	
	public ComparableNode(GeographicPoint location, Double dist, Double dist2) {
		this.location = location;
		this.dist = dist;
		this.dist2 = dist2;
	}

	public GeographicPoint getLocation() {
		return location;
	}

	public void setLocation(GeographicPoint location) {
		this.location = location;
	}

	public Double getDist() {
		return dist;
	}

	public void setDist(Double dist) {
		this.dist = dist;
	}
	
	public Double getDist2() {
		return dist2;
	}

	public void setDist2(Double dist2) {
		this.dist2 = dist2;
	}

	@Override
	public int compareTo(ComparableNode o) {
		double result = (this.getDist() + this.getDist2() - (o.getDist() + o.getDist2()));
		return result < 0 ? -1 : result == 0 ? 0 : 1;
	}
}